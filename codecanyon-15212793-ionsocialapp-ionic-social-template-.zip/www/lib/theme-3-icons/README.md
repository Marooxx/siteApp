View project on: https://icomoon.io

# Tags
To create an annotated tag, enter the following:
```
git tag -a 1.0 -m 'the initial release'
```
Then run:
```
git push origin --tags
```
