Version 1.1 - released 16 July 2016

## Misc
- Update Ionic Version to v.1.3.1
- Update gulp-sass to latest Version
- Fixed a line in scss/common/common.styles.scss that was throwing an error
