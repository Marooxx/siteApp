# Sample database: http://beta.json-generator.com/api/json/get/N1uaMkIde

# Find and Replace ionSocialApp with your own value
# To generate the data we use this tool: http://www.json-generator.com/

# You can find the documentation here: http://bit.ly/ionicthemes-ionSocialApp

## To save all installed plugins to config.xml run
```
cordova plugin save
```

## To install platforms and plugins run:
```
ionic state restore
```
